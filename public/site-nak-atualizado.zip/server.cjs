var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc2) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc2 = __getOwnPropDesc(from, key)) || desc2.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_vite = require("vite");

// src/lib/firebase-admin.ts
var import_app = require("firebase-admin/app");
var import_auth = require("firebase-admin/auth");

// firebase-applet-config.json
var firebase_applet_config_default = {
  projectId: "influential-calculus-xvxch",
  appId: "1:476404528276:web:a6841fd9dcf5dd1c897081",
  apiKey: "AIzaSyCJzL6dv_dQ2nY2Lc84F-6Vyj8mSElzp_Y",
  authDomain: "influential-calculus-xvxch.firebaseapp.com",
  storageBucket: "influential-calculus-xvxch.firebasestorage.app",
  messagingSenderId: "476404528276",
  measurementId: "",
  oAuthClientId: "476404528276-8ksr5n1ubp14q37uc32k1a1aaqovniat.apps.googleusercontent.com",
  recaptchaSiteKey: ""
};

// src/lib/firebase-admin.ts
if (!(0, import_app.getApps)().length) {
  (0, import_app.initializeApp)({
    projectId: firebase_applet_config_default.projectId
  });
}
var adminAuth = (0, import_auth.getAuth)();

// src/middleware/auth.ts
var requireAuth = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized: Missing token" });
  }
  const token = authHeader.split("Bearer ")[1];
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error("Error verifying Firebase ID token:", error);
    return res.status(401).json({ error: "Unauthorized: Invalid token" });
  }
};

// src/db/index.ts
var import_node_postgres = require("drizzle-orm/node-postgres");
var import_pg = require("pg");

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  alunos: () => alunos,
  alunosRelations: () => alunosRelations,
  users: () => users,
  usersRelations: () => usersRelations
});
var import_drizzle_orm = require("drizzle-orm");
var import_pg_core = require("drizzle-orm/pg-core");
var users = (0, import_pg_core.pgTable)("users", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  uid: (0, import_pg_core.text)("uid").notNull().unique(),
  // Firebase Auth UID
  email: (0, import_pg_core.text)("email").notNull(),
  displayName: (0, import_pg_core.text)("display_name"),
  photoUrl: (0, import_pg_core.text)("photo_url"),
  role: (0, import_pg_core.text)("role").default("membro"),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow()
});
var alunos = (0, import_pg_core.pgTable)("alunos", {
  id: (0, import_pg_core.serial)("id").primaryKey(),
  nome: (0, import_pg_core.text)("nome").notNull(),
  telefone: (0, import_pg_core.text)("telefone").notNull(),
  turma: (0, import_pg_core.text)("turma").notNull(),
  prajed: (0, import_pg_core.text)("prajed").default("Branco (Iniciante)"),
  origem: (0, import_pg_core.text)("origem").default("Site NAK Entre Rios"),
  status: (0, import_pg_core.text)("status").default("pendente"),
  userId: (0, import_pg_core.text)("user_uid"),
  createdAt: (0, import_pg_core.timestamp)("created_at").defaultNow()
});
var usersRelations = (0, import_drizzle_orm.relations)(users, ({ many }) => ({
  alunos: many(alunos)
}));
var alunosRelations = (0, import_drizzle_orm.relations)(alunos, ({ one }) => ({
  user: one(users, {
    fields: [alunos.userId],
    references: [users.uid]
  })
}));

// src/db/index.ts
var createPool = () => {
  if (!global._postgresPool) {
    global._postgresPool = new import_pg.Pool({
      host: process.env.SQL_HOST,
      user: process.env.SQL_USER,
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME,
      max: 10,
      connectionTimeoutMillis: 15e3
    });
    global._postgresPool.on("error", (err) => {
      console.error("Unexpected error on idle SQL pool client:", err);
    });
  }
  return global._postgresPool;
};
var pool = createPool();
var db = (0, import_node_postgres.drizzle)(pool, { schema: schema_exports });

// src/db/alunos.ts
var import_drizzle_orm2 = require("drizzle-orm");
async function getDbAlunos() {
  try {
    return await db.select().from(alunos).orderBy((0, import_drizzle_orm2.desc)(alunos.createdAt));
  } catch (error) {
    console.error("Database getDbAlunos failed:", error);
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}
async function insertDbAluno(input) {
  try {
    const result = await db.insert(alunos).values({
      nome: input.nome.trim(),
      telefone: input.telefone.trim(),
      turma: input.turma.trim(),
      prajed: input.prajed || "Branco (Iniciante)",
      origem: input.origem || "Site NAK Entre Rios",
      userId: input.userId || null,
      status: "pendente"
    }).returning();
    return result[0];
  } catch (error) {
    console.error("Database insertDbAluno failed:", error);
    throw new Error("Database insert failed. Please try again later.", { cause: error });
  }
}
async function deleteDbAluno(id) {
  try {
    const result = await db.delete(alunos).where((0, import_drizzle_orm2.eq)(alunos.id, id)).returning();
    return result[0];
  } catch (error) {
    console.error("Database deleteDbAluno failed:", error);
    throw new Error("Database delete failed. Please try again later.", { cause: error });
  }
}

// src/db/users.ts
var import_drizzle_orm3 = require("drizzle-orm");
async function getOrCreateUser(uid, email, displayName, photoUrl) {
  try {
    const result = await db.insert(users).values({
      uid,
      email,
      displayName: displayName || null,
      photoUrl: photoUrl || null
    }).onConflictDoUpdate({
      target: users.uid,
      set: {
        email,
        ...displayName ? { displayName } : {},
        ...photoUrl ? { photoUrl } : {}
      }
    }).returning();
    return result[0];
  } catch (error) {
    console.error("Database getOrCreateUser failed:", error);
    throw new Error("Database user sync failed.", { cause: error });
  }
}

// server.ts
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.set("trust proxy", true);
app.use(import_express.default.json());
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }
  next();
});
var DATA_DIR = import_path.default.join(process.cwd(), "data");
var ALUNOS_FILE = import_path.default.join(DATA_DIR, "alunos.json");
function ensureDataStorage() {
  if (!import_fs.default.existsSync(DATA_DIR)) {
    import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!import_fs.default.existsSync(ALUNOS_FILE)) {
    import_fs.default.writeFileSync(ALUNOS_FILE, JSON.stringify([], null, 2), "utf-8");
  }
}
function getLocalAlunos() {
  ensureDataStorage();
  try {
    const raw = import_fs.default.readFileSync(ALUNOS_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    console.error("Erro ao ler alunos locais:", err);
    return [];
  }
}
function saveLocalAlunos(alunos2) {
  ensureDataStorage();
  try {
    import_fs.default.writeFileSync(ALUNOS_FILE, JSON.stringify(alunos2, null, 2), "utf-8");
  } catch (err) {
    console.error("Erro ao salvar alunos locais:", err);
  }
}
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.get(["/api/download-zip", "/site-nak-atualizado.zip"], (req, res) => {
  const zipPath = import_path.default.join(process.cwd(), "public", "site-nak-atualizado.zip");
  if (import_fs.default.existsSync(zipPath)) {
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="site-nak-atualizado.zip"');
    return res.sendFile(zipPath);
  }
  return res.status(404).send("Arquivo zip n\xE3o encontrado. Execute o build primeiro.");
});
app.post("/api/auth/sync", requireAuth, async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "N\xE3o autenticado" });
    }
    const { uid, email, name, picture } = req.user;
    const dbUser = await getOrCreateUser(uid, email || "", name, picture);
    return res.json({ user: dbUser });
  } catch (error) {
    console.error("Falha ao sincronizar usu\xE1rio:", error);
    return res.status(500).json({ error: "Erro ao autenticar usu\xE1rio" });
  }
});
app.get("/api/auth/me", requireAuth, async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: "N\xE3o autenticado" });
    }
    const { uid, email, name, picture } = req.user;
    const dbUser = await getOrCreateUser(uid, email || "", name, picture);
    return res.json({ user: dbUser });
  } catch (error) {
    console.error("Falha ao obter usu\xE1rio atual:", error);
    return res.status(500).json({ error: "Erro ao obter dados do usu\xE1rio" });
  }
});
app.get("/api/alunos", async (req, res) => {
  try {
    const sqlAlunos = await getDbAlunos();
    if (Array.isArray(sqlAlunos) && sqlAlunos.length > 0) {
      return res.json({
        alunos: sqlAlunos,
        total: sqlAlunos.length
      });
    }
  } catch (dbErr) {
    console.error("Falha ao consultar banco Cloud SQL:", dbErr);
  }
  const localAlunos = getLocalAlunos();
  return res.json({
    alunos: localAlunos,
    total: localAlunos.length
  });
});
app.post("/api/alunos", async (req, res) => {
  try {
    const { nome, telefone, turma, prajed, origem, userId } = req.body;
    if (!nome || !telefone || !turma) {
      return res.status(400).json({
        error: "Campos obrigat\xF3rios: nome, telefone e turma."
      });
    }
    let alunoCriado = null;
    try {
      alunoCriado = await insertDbAluno({
        nome: String(nome),
        telefone: String(telefone),
        turma: String(turma),
        prajed: prajed || "Branco (Iniciante)",
        origem: origem || "Site NAK Entre Rios",
        userId: userId || void 0
      });
    } catch (sqlErr) {
      console.error("Erro na inser\xE7\xE3o Cloud SQL, acionando grava\xE7\xE3o local:", sqlErr);
    }
    const localObj = alunoCriado || {
      id: `local_${Date.now()}`,
      nome: String(nome).trim(),
      telefone: String(telefone).trim(),
      turma: String(turma).trim(),
      prajed: prajed || "Branco (Iniciante)",
      origem: origem || "Site NAK Entre Rios",
      status: "pendente",
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    const locais = getLocalAlunos();
    locais.unshift(localObj);
    saveLocalAlunos(locais);
    return res.status(201).json({
      success: true,
      message: "Matr\xEDcula realizada com sucesso!",
      aluno: localObj
    });
  } catch (err) {
    console.error("Exce\xE7\xE3o ao matricular aluno:", err);
    return res.status(500).json({ error: "Erro ao processar matr\xEDcula" });
  }
});
app.delete("/api/alunos/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const numericId = parseInt(id, 10);
    if (!isNaN(numericId)) {
      try {
        await deleteDbAluno(numericId);
      } catch (sqlErr) {
        console.error("Erro ao deletar no Cloud SQL:", sqlErr);
      }
    }
    const alunos2 = getLocalAlunos();
    const filtrados = alunos2.filter((a) => String(a.id) !== String(id));
    saveLocalAlunos(filtrados);
    return res.json({ success: true, message: "Aluno removido com sucesso." });
  } catch (err) {
    return res.status(500).json({ error: "Erro ao remover aluno" });
  }
});
async function initServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server Muay Thai rodando na porta ${PORT}`);
  });
}
initServer().catch((err) => {
  console.error("Falha ao iniciar servidor:", err);
});
//# sourceMappingURL=server.cjs.map
